/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mp4_generics_stelly;

/**
 *
 * @author ethan
 */
public class MP4_Generics_Stelly {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
